"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.config = {
    "jwt": {
        "secret": "helloworld"
    }
};
//# sourceMappingURL=config.js.map